package com.zinnia.assignment.service;

import java.text.DecimalFormat;
import java.util.ArrayList;

import com.zinnia.assignment.constants.Constants;

public class ArithmeticService {
	
	private static ArrayList<String> memory = new ArrayList<>();

    enum Operator {
        PLUS,
        MINUS,
        MULTY,
        DIVIDE,
        POWER,
        EQUAL
    }

    DecimalFormat format = new DecimalFormat("0.#");

    private boolean  operationHappen  = false;
    private Double   previousInput    = null;
    private Operator previousOperator = null;

    public String getTotalString() {
        String output = Constants.EMPTY;
        if (previousInput != null) {
            return format.format(previousInput);
        }
        return output;
    }
    
    public double getEulerNumber() {
    	double base=1.01;
		int exponent = 100;
		double result = 1;
		while (exponent != 0)
        {
            result *= base;
            --exponent;
        }
		
		return result;
    }
    
    public double getGrowthRate(String k, String t) {
    	double product = convertToNumber(k) * convertToNumber(t);
    	double result = 1;
    	double eulerNumber = getEulerNumber();
        for (int i = 0; i < product; i++) {
            result *= eulerNumber;
        }
        return result;
    }

    public void total(String n) {
        doOperation(n, Operator.EQUAL);
    }

    public void resetTotal() {
        previousInput = null;
        previousOperator = null;
    }

    public void add(String n) {
        doOperation(n, Operator.PLUS);
    }

    public void subtract(String n) {
        doOperation(n, Operator.MINUS);
    }

    public void multiply(String n) {
        doOperation(n, Operator.MULTY);
    }

    public void divide(String n) {
        doOperation(n, Operator.DIVIDE);
    }

    public void power(String n) {
        doOperation(n, Operator.POWER);
    }

    private void doOperation(String n, Operator operator) {
        doOperation(n);
        previousOperator = operator;
    }

    private void doOperation(String n) {
        operationHappen = previousInput != null;
        double currentInput = convertToNumber(n);
        if (operationHappen) {
            if (previousOperator != null) {
                previousInput = operation(previousInput, previousOperator, currentInput);
            }
        } else {
            previousInput = currentInput;
        }
    }

    private double convertToNumber(String n) {
        return Double.parseDouble(n);
    }

    private double operation(double left, Operator operator, double right) {
        double result = 0;
        switch (operator) {
            case PLUS:
                result = (left + right);
                break;
            case MINUS:
                result = (left - right);
                break;
            case MULTY:
                result = (left * right);
                break;
            case DIVIDE:
                result = (left / right);
                break;
            case POWER:
                result = 1;
                for (int i = 0; i < right; i++) {
                    result *= left;
                }
                break;
            case EQUAL:
                result = right;
                break;
            default:
                result = 0;
                break;
        }
        return result;
    }

	public static ArrayList<String> getMemory() {
		return memory;
	}
    
}
