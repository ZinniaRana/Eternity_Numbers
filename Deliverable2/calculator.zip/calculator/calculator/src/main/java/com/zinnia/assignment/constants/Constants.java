package com.zinnia.assignment.constants;

public interface Constants {
	
	public static final String FONT_STYLE      = "monspaced";
	public static final String EQUALS          = "=";
	public static final Double ZERO            = 0.0;
	public static final String BUTTON_ORDER    = "1234567890e ";
	public static final String SPACE		   = " ";
	public static final String EMPTY           = "";
	
	
	//button constatnts
	public static final String BUTTON_SAVE     = "SAVE";
	public static final String BUTTON_MEMORY   = "MEM";
	public static final String BUTTON_ENTER    = "ENTER";
	public static final String BUTTON_POWER    = "^";
	public static final String BUTTON_OPERATION = "OP";
	public static final String BUTTON_CLEAR     = "C";
	public static final String BUTTON_PLUS      = "+";
	public static final String BUTTON_MINUS     = "-";
	public static final String BUTTON_MULTIPLY  = "*";
	public static final String BUTTON_DIVIDE    = "/";
	public static final String BUTTON_E         = "e";
	
	//mode constants
	public static final String CALCULATOR_MODE        = "Mode: Calculator";
	public static final String MEMORY_MODE            = "Mode: Memory";
	public static final String SAVED_STATE            = "State Saved!";
	public static final String MODE_GROWTH_FUNC_K     = "Mode: Growth Function |  k";
	public static final String MODE_GROWTH_FUNC_T     = "Mode: Growth Function |  t";

}
