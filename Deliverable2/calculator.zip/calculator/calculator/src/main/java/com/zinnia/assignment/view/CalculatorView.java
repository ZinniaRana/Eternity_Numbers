package com.zinnia.assignment.view;

import javax.swing.*;
import javax.swing.border.Border;

import com.zinnia.assignment.constants.Constants;

import java.awt.*;
import java.awt.event.ActionListener;

public class CalculatorView extends JFrame {

    private final Font       BIGGER_FONT = new Font(Constants.FONT_STYLE, Font.PLAIN, 20);
    private       JTextField textField;
    private       JTextField modeTextField;
    private       boolean    number      = true;
    private       String     equalOp     = Constants.EQUALS;
    private       Double     output      = Constants.ZERO;
    private       JPanel     numberPanel;
    private       JPanel     operatorPanel;

    public CalculatorView() {
        textField = new JTextField(Constants.EMPTY, 12);
        textField.setHorizontalAlignment(JTextField.RIGHT);
        textField.setFont(BIGGER_FONT);
        String buttonOrder = Constants.BUTTON_ORDER;
        numberPanel = new JPanel();
        numberPanel.setLayout(new GridLayout(4, 4, 4, 4));
        for (int i = 0; i < buttonOrder.length(); i++) {
            String key = buttonOrder.substring(i, i + 1);
            if (key.equals(Constants.SPACE)) {
                numberPanel.add(new JLabel(Constants.EMPTY));
            } else {
                JButton button = new JButton(key);
                button.setFont(BIGGER_FONT);
                numberPanel.add(button);
            }
        }
        operatorPanel = new JPanel();
        operatorPanel.setLayout(new GridLayout(4, 4, 4, 4));
        String[] opOrder = { Constants.BUTTON_PLUS, Constants.BUTTON_MINUS,
        		             Constants.BUTTON_MULTIPLY, Constants.BUTTON_DIVIDE, 
        		             Constants.EQUALS, Constants.BUTTON_CLEAR,
        		             Constants.BUTTON_POWER,Constants.BUTTON_OPERATION,
        		             Constants.BUTTON_ENTER,Constants.BUTTON_SAVE,
        		             Constants.BUTTON_MEMORY };
        for (int i = 0; i < opOrder.length; i++) {
            JButton button = new JButton(opOrder[i]);
            button.setFont(BIGGER_FONT);
            operatorPanel.add(button);
        }
        JPanel pan = new JPanel();
        JPanel newPanel = new JPanel();
        newPanel.setLayout(new GridLayout(1,2,2,1));
        modeTextField = new JTextField(Constants.CALCULATOR_MODE);
        modeTextField.setEnabled(false);
        modeTextField.setFont(BIGGER_FONT);
        System.out.println(modeTextField.getWidth());
        newPanel.add(modeTextField,BorderLayout.EAST);
        newPanel.add(textField,BorderLayout.WEST);
        pan.setLayout(new BorderLayout(12, 12));
        pan.add(newPanel,BorderLayout.NORTH);
        pan.add(numberPanel, BorderLayout.CENTER);
        pan.add(operatorPanel, BorderLayout.EAST);
        this.setContentPane(pan);
        this.pack();
        this.setTitle("Calculator");
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public JTextField getTextField() {
        return textField;
    }

    public boolean isNumber() {
        return number;
    }

    public String getEqualOp() {
        return equalOp;
    }

    public Double getOutput() {
        return output;
    }

    public JPanel getNumberPanel() {
        return numberPanel;
    }

    public JPanel getOperatorPanel() {
        return operatorPanel;
    }

	public JTextField getModeTextField() {
		return modeTextField;
	}

	public void setModeTextField(JTextField modeTextField) {
		this.modeTextField = modeTextField;
	}
}
