package com.zinnia.assignment;

import com.zinnia.assignment.presenter.CalculatorPresenter;
import com.zinnia.assignment.service.ArithmeticService;
import com.zinnia.assignment.view.CalculatorView;


public class App 
{
    public static void main( String[] args )
    {
        CalculatorView view = new CalculatorView();
        ArithmeticService service = new ArithmeticService();
        CalculatorPresenter presenter = new CalculatorPresenter(view, service);
        presenter.go();
    }
}
