package com.zinnia.assignment.presenter;

import javax.swing.*;

import com.zinnia.assignment.constants.Constants;
import com.zinnia.assignment.service.ArithmeticService;
import com.zinnia.assignment.view.CalculatorView;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculatorPresenter {

	private CalculatorView view;
	private ArithmeticService service;
	private boolean number;
	private boolean status = true;
	private String k, t;
	private boolean userOperationMode = false;
	private boolean resultMode = false;
	private int listLength;

	public CalculatorPresenter(CalculatorView view, ArithmeticService service) {
		this.view = view;
		number = true;
		this.service = service;
		bind();
	}

	private void bind() {
		Component[] numComponents = view.getNumberPanel().getComponents();
		for (Component component : numComponents) {
			if (component instanceof JButton) {
				JButton button = (JButton) component;
				button.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent event) {
						String digit = event.getActionCommand();
						if (number) {
							if (digit.equals(Constants.BUTTON_E))

								view.getTextField().setText(String.format("%.5f", service.getEulerNumber()));
							else
								view.getTextField().setText(digit);
							number = false;
						} else {
							if (digit.equals(Constants.BUTTON_E))
								view.getTextField().setText(String.format("%.5f", service.getEulerNumber()));
							else
								view.getTextField().setText(view.getTextField().getText() + digit);
						}
					}
				});
			}
		}

		Component[] operatorComponents = view.getOperatorPanel().getComponents();
		for (Component component : operatorComponents) {
			JButton button = (JButton) component;
			button.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					String displayText = view.getTextField().getText();
					String operator = e.getActionCommand();
					if (operator.equals(Constants.BUTTON_CLEAR)) {
						view.getTextField().setText(Constants.EMPTY);
						view.getModeTextField().setText(Constants.CALCULATOR_MODE);
						status = true;
						userOperationMode = false;
						resultMode = false;
						listLength = ArithmeticService.getMemory().size();
						service.resetTotal();
					} else if (operator.equals(Constants.BUTTON_OPERATION)) {
						view.getModeTextField().setText(Constants.MODE_GROWTH_FUNC_K);
						userOperationMode = true;
					} else if (!displayText.isEmpty()) {
						if (operator.equals(Constants.EQUALS)) {
							service.total(displayText);
						} else if (operator.equals(Constants.BUTTON_ENTER)) {
							if (userOperationMode) {
								if (status == true) {
									k = view.getTextField().getText();
									view.getModeTextField().setText(Constants.MODE_GROWTH_FUNC_T);
								} else {
									t = view.getTextField().getText();
									resultMode = true;
								}
								status = !status;
							}
						} else if (operator.equals(Constants.BUTTON_PLUS)) {
							service.add(displayText);
						} else if (operator.equals(Constants.BUTTON_MINUS)) {
							service.subtract(displayText);
						} else if (operator.equals(Constants.BUTTON_MULTIPLY)) {
							service.multiply(displayText);
						} else if (operator.equals(Constants.BUTTON_DIVIDE)) {
							service.divide(displayText);
						} else if (operator.equals(Constants.BUTTON_POWER)) {
							service.power(displayText);
						} else if (operator.equals(Constants.BUTTON_SAVE)) {
							view.getModeTextField().setText(Constants.SAVED_STATE);
							ArithmeticService.getMemory().add(displayText);
							listLength = ArithmeticService.getMemory().size();
						}
						if (operator.equals(Constants.EQUALS)) {
							view.getTextField().setText(service.getTotalString());
						} else if (operator.equals(Constants.BUTTON_MEMORY)) {
							view.getModeTextField().setText(Constants.MEMORY_MODE);
							if (listLength != 0)
								view.getTextField().setText(ArithmeticService.getMemory().get(--listLength));
						} else if (operator.equals(Constants.BUTTON_ENTER) && resultMode) {
							System.out.println(service.getGrowthRate(k, t));
							view.getTextField().setText(Constants.EMPTY + service.getGrowthRate(k, t));
						} else {
							view.getTextField().setText(Constants.EMPTY);
						}
					} else if (operator.equals(Constants.BUTTON_MEMORY)) {
						view.getModeTextField().setText(Constants.MEMORY_MODE);
						if (listLength != 0)
							view.getTextField().setText(ArithmeticService.getMemory().get(--listLength));
					}
				}
			});
		}
	}

	public void go() {
		view.setVisible(true);
	}

}
