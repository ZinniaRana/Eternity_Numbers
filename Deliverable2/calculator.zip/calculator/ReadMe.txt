*****READ ME****

1. Click on File -> Import -> Existing Maven Project
2. Open App.javaand execute as java project
Converting into executeable jar file
